#  WDD: JavaScript - Formatted Current Date

A Pen created on CodePen.io. Original URL: [https://codepen.io/Jordancarron11/pen/mdjEjmq](https://codepen.io/Jordancarron11/pen/mdjEjmq).

